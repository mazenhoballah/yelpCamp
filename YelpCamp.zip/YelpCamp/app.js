var express    = require('express'),
bodyparse      = require("body-parser"),
mongoose       = require("mongoose"),
methodOverride = require('method-override'),
Campground     = require("./models/campground"),
Comment        = require("./models/comment"),
seedDB         = require("./seeds")
app            = express(),
port           = 8080,
hostname       = 'localhost';
mongoose.connect("mongodb://localhost:27017/yelp_camp",
{ 
    useNewUrlParser: true, 
    useUnifiedTopology: true,
    useCreateIndex: true,
    useFindAndModify: false
}
); 
//lama ya3tina 3al node app.js warning mnzid l useNewUrlParser

app.use(bodyparse.urlencoded({extended:true}));
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(methodOverride('_method'));

seedDB();

app.get("/",(req,res)=>{
    res.render("landing");
});

//Index Route -shows all campgrounds in the db
app.get("/campgrounds",(req,res)=>{
    //get all campgrounds from db
    Campground.find({},(err, allCampgrounds)=>{
        if(err){
            console.log(err);
        }else{
            res.render("campgrounds/index",{campgrounds:allCampgrounds});
        }
    });  
    //res.render("campgrounds",{campgrounds:campgrounds});
});

//Create Route  -add a new campgrpound to the db
app.post("/campgrounds",(req,res)=>{
    //get data from form and add to campgrounds array
    var name = req.body.name;
    var image = req.body.image;
    var desc = req.body.description;
    var newCamp = {name:name,image:image, description:desc};
    Campground.create(newCamp,(err,newlyCreated)=>{
        if(err){
            console.log(err);
        }else{
            res.redirect("/campgrounds");
        }
    });
    
});

//New Route  --shows form to create new campground to db
app.get("/campgrounds/new",(req,res)=>{
    res.render("campgrounds/new");
});

//====================
//COMMENTS ROUTES
//=====================
app.post("/campgrounds/:id/comments",(req,res)=>{
    Campground.findById(req.params.id,(err, campground)=>{
        Comment.create(req.body.comment,(err, comment)=>{
            if(err){
                console.log(err);
                res.redirect("/campgrounds");
            }else{
                campground.comments.push(comment);
                campground.save();
                res.redirect("/campgrounds/"+ campground._id);
            }
        })
    });
    
});

app.get("/campgrounds/:id/comments/new",(req,res)=>{
    //find campground by ID
    Campground.findById(req.params.id,(err, campground)=>{
        if(err){
            console.log(err);
        }else{
            res.render("comments/new",{campground:campground});
        }
    });
    
});
//THIS ROUTE SHOULD ALWAYS BE AFTER THE NEW ROUTE ABOVE OR IT WILL TREATE THE /NEW AS AN ID
//SHOW ROUTE -shows more info about one campground
app.get("/campgrounds/:id",(req, res)=>{
    //find the campground with the provided ID
    Campground.findById(req.params.id).populate("comments").exec((err, foundCampground)=>{
        if(err){
            console.log(err);
        }else{
            //render show template  with that  campground
            res.render("campgrounds/show", {campground: foundCampground});
        }
    });
    
});

app.delete("/campgrounds/:id", (req,res)=>{
    Campground.findByIdAndRemove(req.params.id, (err)=>{
        if(err){
            res.redirect("/campgrounds");
        }else{
            //render show template  with that  campground
            res.redirect("/campgrounds");        
        }
    });
});

app.listen(port, hostname, ()=>{
    console.log('The YelCamp server is starting!');
});