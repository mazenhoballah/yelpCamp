var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/blog_demo2",{ 
    useNewUrlParser: true, 
    useUnifiedTopology: true,
    useCreateIndex: true,
    useFindAndModify: false
});


var Post = require("./models/post");

var User = require("./models/user");

// User.create({
//     email:"m@gmail.com",
//     name:"mazen"
// });

Post.create({
    title:"DDDD",
    content:"there is the content"
},(err,post)=>{
    User.findOne({email:"m@gmail.com"},(err,foundUser)=>{
        if(err){
            console.log(err);
        }else{
            foundUser.posts.push(post);
            foundUser.save((err, data)=>{
                if(err){
                    console.log(err);
                }else{
                    console.log(data);
                }
            });
        }
    });
});

// //find user
// //find all posts for that user

// User.findOne({email:"m@gmail.com"}).populate("posts").exec((err,user)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log(user);
//     }
// });